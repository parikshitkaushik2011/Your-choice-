import { Route, Switch } from 'wouter'
import { Toaster } from 'sonner'
import { AppProvider } from './store'
import Layout from './components/Layout'
import Home from './pages/Home'
import Shop from './pages/Shop'
import ProductDetail from './pages/ProductDetail'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import OrderSuccess from './pages/OrderSuccess'
import Login from './pages/Login'
import Register from './pages/Register'
import Profile from './pages/Profile'
import Orders from './pages/Orders'
import Wishlist from './pages/Wishlist'
import Admin from './pages/Admin'
import NotFound from './pages/not-found'

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/shop" component={Shop} />
          <Route path="/product/:id" component={ProductDetail} />
          <Route path="/cart" component={Cart} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/order-success" component={OrderSuccess} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/profile" component={Profile} />
          <Route path="/orders" component={Orders} />
          <Route path="/wishlist" component={Wishlist} />
          <Route path="/admin" component={Admin} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#0B0B0B',
            border: '1px solid rgba(212, 175, 55, 0.3)',
            color: '#fff',
          },
        }}
      />
    </AppProvider>
  )
}
