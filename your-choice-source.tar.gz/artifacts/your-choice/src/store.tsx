import { createContext, useContext, useState, ReactNode } from 'react'
import { Product } from './data/products'

export interface Address {
  fullName: string
  phone: string
  street: string
  city: string
  state: string
  pincode: string
}

export interface CartItem {
  product: Product
  size: string
  color: string
  quantity: number
}

export interface WishlistItem {
  product: Product
}

export interface Order {
  id: string
  items: CartItem[]
  address: Address
  paymentMethod: string
  total: number
  status: 'Confirmed' | 'Processing' | 'Shipped' | 'Delivered'
  date: string
}

export interface User {
  name: string
  email: string
  phone: string
  password: string
}

interface AppState {
  cartItems: CartItem[]
  wishlistItems: WishlistItem[]
  user: User | null
  orders: Order[]
  isCartOpen: boolean
  isSearchOpen: boolean
  cartTotal: number
  cartCount: number
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void
  removeFromCart: (productId: string, size: string, color: string) => void
  updateQuantity: (productId: string, size: string, color: string, quantity: number) => void
  toggleWishlist: (product: Product) => void
  isInWishlist: (productId: string) => boolean
  login: (email: string, password: string) => boolean
  register: (name: string, email: string, password: string, phone: string) => boolean
  logout: () => void
  updateUser: (updates: Partial<User>) => void
  placeOrder: (address: Address, paymentMethod: string) => string
  setCartOpen: (open: boolean) => void
  setSearchOpen: (open: boolean) => void
}

const AppContext = createContext<AppState | null>(null)

const DEMO_ADMIN: User = {
  name: 'Admin',
  email: 'admin@yourchoice.com',
  phone: '9467259111',
  password: 'admin123',
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([])
  const [user, setUser] = useState<User | null>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [users, setUsers] = useState<User[]>([DEMO_ADMIN])

  const cartTotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)

  const addToCart = (product: Product, size: string, color: string, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(
        i => i.product.id === product.id && i.size === size && i.color === color
      )
      if (existing) {
        return prev.map(i =>
          i.product.id === product.id && i.size === size && i.color === color
            ? { ...i, quantity: i.quantity + quantity }
            : i
        )
      }
      return [...prev, { product, size, color, quantity }]
    })
  }

  const removeFromCart = (productId: string, size: string, color: string) => {
    setCartItems(prev =>
      prev.filter(i => !(i.product.id === productId && i.size === size && i.color === color))
    )
  }

  const updateQuantity = (productId: string, size: string, color: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, size, color)
      return
    }
    setCartItems(prev =>
      prev.map(i =>
        i.product.id === productId && i.size === size && i.color === color
          ? { ...i, quantity }
          : i
      )
    )
  }

  const toggleWishlist = (product: Product) => {
    setWishlistItems(prev => {
      const exists = prev.find(i => i.product.id === product.id)
      if (exists) return prev.filter(i => i.product.id !== product.id)
      return [...prev, { product }]
    })
  }

  const isInWishlist = (productId: string) =>
    wishlistItems.some(i => i.product.id === productId)

  const login = (email: string, password: string): boolean => {
    const found = users.find(u => u.email === email && u.password === password)
    if (found) {
      setUser(found)
      return true
    }
    return false
  }

  const register = (name: string, email: string, password: string, phone: string): boolean => {
    const exists = users.find(u => u.email === email)
    if (exists) return false
    const newUser: User = { name, email, password, phone }
    setUsers(prev => [...prev, newUser])
    setUser(newUser)
    return true
  }

  const logout = () => setUser(null)

  const updateUser = (updates: Partial<User>) => {
    setUser(prev => prev ? { ...prev, ...updates } : null)
    setUsers(prev => prev.map(u => u.email === user?.email ? { ...u, ...updates } : u))
  }

  const placeOrder = (address: Address, paymentMethod: string): string => {
    const orderId = 'YC' + Date.now().toString().slice(-8)
    const order: Order = {
      id: orderId,
      items: [...cartItems],
      address,
      paymentMethod,
      total: cartTotal + (cartTotal > 5000 ? 0 : 99),
      status: 'Confirmed',
      date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    }
    setOrders(prev => [order, ...prev])
    setCartItems([])
    return orderId
  }

  const setCartOpen = (open: boolean) => setIsCartOpen(open)
  const setSearchOpen = (open: boolean) => setIsSearchOpen(open)

  return (
    <AppContext.Provider value={{
      cartItems, wishlistItems, user, orders,
      isCartOpen, isSearchOpen, cartTotal, cartCount,
      addToCart, removeFromCart, updateQuantity,
      toggleWishlist, isInWishlist,
      login, register, logout, updateUser, placeOrder,
      setCartOpen, setSearchOpen,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp(): AppState {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
