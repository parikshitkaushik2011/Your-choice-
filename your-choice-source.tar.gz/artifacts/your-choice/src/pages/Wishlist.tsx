import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '../store'
import ProductCard from '../components/ProductCard'

export default function Wishlist() {
  const { wishlistItems, toggleWishlist } = useApp()
  const [, navigate] = useLocation()

  if (wishlistItems.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Heart className="w-20 h-20 text-luxury-gold/20 mx-auto mb-6" />
          <h2 className="text-2xl font-playfair font-bold mb-3">Your wishlist is empty</h2>
          <p className="text-luxury-light/50 mb-8 text-sm">Save your favourite items and shop them later.</p>
          <button onClick={() => navigate('/shop')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all">
            Start Shopping
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">Saved Items</p>
          <h1 className="text-3xl font-playfair font-bold">My Wishlist <span className="text-luxury-gold text-xl ml-2">({wishlistItems.length})</span></h1>
        </div>
        <button
          onClick={() => navigate('/shop')}
          className="flex items-center gap-1 text-sm text-luxury-gold hover:underline"
        >
          Continue Shopping <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {wishlistItems.map(({ product }) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative"
            >
              <button
                onClick={() => {
                  toggleWishlist(product)
                  toast('Removed from wishlist', { icon: '💔' })
                }}
                className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 hover:bg-red-500/20 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <ProductCard product={product} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}
