import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { Check, MapPin, CreditCard, ShoppingBag, ChevronRight, ArrowLeft } from 'lucide-react'
import { useApp } from '../store'
import { Address } from '../store'

type AddressForm = {
  fullName: string
  phone: string
  street: string
  city: string
  state: string
  pincode: string
}

const PAYMENT_OPTIONS = [
  { id: 'cod', label: 'Cash on Delivery', icon: '💵', desc: 'Pay when you receive' },
  { id: 'upi', label: 'UPI Payment', icon: '📱', desc: 'Google Pay, PhonePe, Paytm' },
  { id: 'card', label: 'Credit / Debit Card', icon: '💳', desc: 'Visa, Mastercard, RuPay' },
]

const STEPS = ['Address', 'Payment', 'Review']

export default function Checkout() {
  const { cartItems, cartTotal, placeOrder, user } = useApp()
  const [, navigate] = useLocation()
  const [step, setStep] = useState(0)
  const [address, setAddress] = useState<Address | null>(null)
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [upiId, setUpiId] = useState('')
  const [placing, setPlacing] = useState(false)

  const { register, handleSubmit, formState: { errors } } = useForm<AddressForm>({
    defaultValues: user ? { fullName: user.name, phone: user.phone } : undefined,
  })

  const deliveryFee = cartTotal > 5000 ? 0 : 99
  const finalTotal = cartTotal + deliveryFee

  if (cartItems.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <ShoppingBag className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
        <h2 className="text-2xl font-playfair font-bold mb-3">Nothing to checkout</h2>
        <button onClick={() => navigate('/shop')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Shop Now</button>
      </div>
    )
  }

  const onAddressSubmit = (data: AddressForm) => {
    setAddress(data)
    setStep(1)
  }

  const placeOrderNow = async () => {
    if (!address) return
    setPlacing(true)
    await new Promise(r => setTimeout(r, 1500))
    const orderId = placeOrder(address, paymentMethod)
    navigate(`/order-success?id=${orderId}`)
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      {/* Steps */}
      <div className="flex items-center justify-center gap-0 mb-10">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center">
            <div className="flex flex-col items-center">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-all ${i < step ? 'bg-luxury-gold border-luxury-gold text-luxury-black' : i === step ? 'border-luxury-gold text-luxury-gold' : 'border-luxury-gold/20 text-luxury-light/30'}`}>
                {i < step ? <Check className="w-4 h-4" /> : i + 1}
              </div>
              <p className={`text-xs mt-1 font-medium ${i === step ? 'text-luxury-gold' : i < step ? 'text-luxury-gold/60' : 'text-luxury-light/30'}`}>{s}</p>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`w-16 sm:w-24 h-px mx-3 mb-5 transition-all ${i < step ? 'bg-luxury-gold' : 'bg-luxury-gold/15'}`} />
            )}
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main */}
        <div className="lg:col-span-2">
          {/* Step 0: Address */}
          {step === 0 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <div className="flex items-center gap-2 mb-5">
                <MapPin className="w-5 h-5 text-luxury-gold" />
                <h2 className="text-xl font-playfair font-bold">Delivery Address</h2>
              </div>
              <form onSubmit={handleSubmit(onAddressSubmit)} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Full Name *</label>
                    <input {...register('fullName', { required: 'Full name required', minLength: { value: 2, message: 'Name too short' } })} className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="Arvind Kaushik" />
                    {errors.fullName && <p className="text-xs text-red-400 mt-1">{errors.fullName.message}</p>}
                  </div>
                  <div>
                    <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Phone Number *</label>
                    <input {...register('phone', { required: 'Phone required', minLength: { value: 10, message: 'Enter 10 digit number' }, maxLength: { value: 10, message: 'Enter 10 digit number' } })} type="tel" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="9467259111" />
                    {errors.phone && <p className="text-xs text-red-400 mt-1">{errors.phone.message}</p>}
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Street Address *</label>
                  <input {...register('street', { required: 'Street address required', minLength: { value: 5, message: 'Enter full address' } })} className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="C/O Bhawani Medical Store, Main Market" />
                  {errors.street && <p className="text-xs text-red-400 mt-1">{errors.street.message}</p>}
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">City *</label>
                    <input {...register('city', { required: 'City required' })} className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="City" />
                    {errors.city && <p className="text-xs text-red-400 mt-1">{errors.city.message}</p>}
                  </div>
                  <div>
                    <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">State *</label>
                    <input {...register('state', { required: 'State required' })} className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="Haryana" />
                    {errors.state && <p className="text-xs text-red-400 mt-1">{errors.state.message}</p>}
                  </div>
                  <div>
                    <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">Pincode *</label>
                    <input {...register('pincode', { required: 'Pincode required', minLength: { value: 6, message: 'Enter 6 digit pincode' }, maxLength: { value: 6, message: 'Enter 6 digit pincode' } })} className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" placeholder="125001" />
                    {errors.pincode && <p className="text-xs text-red-400 mt-1">{errors.pincode.message}</p>}
                  </div>
                </div>
                <button type="submit" className="w-full py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2">
                  Continue to Payment <ChevronRight className="w-4 h-4" />
                </button>
              </form>
            </motion.div>
          )}

          {/* Step 1: Payment */}
          {step === 1 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <div className="flex items-center gap-2 mb-5">
                <CreditCard className="w-5 h-5 text-luxury-gold" />
                <h2 className="text-xl font-playfair font-bold">Payment Method</h2>
              </div>
              <div className="space-y-3 mb-6">
                {PAYMENT_OPTIONS.map(opt => (
                  <label key={opt.id} className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod === opt.id ? 'border-luxury-gold bg-luxury-gold/5' : 'border-luxury-gold/15 hover:border-luxury-gold/40'}`}>
                    <input type="radio" name="payment" value={opt.id} checked={paymentMethod === opt.id} onChange={e => setPaymentMethod(e.target.value)} className="accent-luxury-gold w-4 h-4" />
                    <span className="text-2xl">{opt.icon}</span>
                    <div>
                      <p className="font-semibold text-sm">{opt.label}</p>
                      <p className="text-xs text-luxury-light/40">{opt.desc}</p>
                    </div>
                  </label>
                ))}
              </div>

              {paymentMethod === 'upi' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-5">
                  <label className="block text-xs text-luxury-light/60 mb-1.5 uppercase tracking-widest">UPI ID</label>
                  <input value={upiId} onChange={e => setUpiId(e.target.value)} placeholder="yourname@upi" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
                </motion.div>
              )}

              {paymentMethod === 'card' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-5 space-y-3">
                  <input placeholder="Card Number" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
                  <div className="grid grid-cols-2 gap-3">
                    <input placeholder="MM / YY" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
                    <input placeholder="CVV" type="password" className="w-full px-4 py-2.5 bg-white/5 border border-luxury-gold/20 rounded-xl text-sm text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors" />
                  </div>
                </motion.div>
              )}

              <div className="flex gap-3">
                <button onClick={() => setStep(0)} className="flex items-center gap-1.5 px-4 py-2.5 border border-luxury-gold/20 text-luxury-light/60 rounded-xl text-sm hover:text-luxury-gold hover:border-luxury-gold/40 transition-colors">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button onClick={() => setStep(2)} className="flex-1 py-2.5 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2">
                  Review Order <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Review */}
          {step === 2 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <h2 className="text-xl font-playfair font-bold mb-5">Review Your Order</h2>

              {address && (
                <div className="p-4 bg-white/[0.02] border border-luxury-gold/15 rounded-xl mb-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs text-luxury-gold uppercase tracking-widest mb-1">Delivering to</p>
                      <p className="font-semibold text-sm">{address.fullName}</p>
                      <p className="text-xs text-luxury-light/50 mt-0.5">{address.street}, {address.city}, {address.state} - {address.pincode}</p>
                      <p className="text-xs text-luxury-light/50">📞 {address.phone}</p>
                    </div>
                    <button onClick={() => setStep(0)} className="text-xs text-luxury-gold hover:underline">Edit</button>
                  </div>
                </div>
              )}

              <div className="p-4 bg-white/[0.02] border border-luxury-gold/15 rounded-xl mb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-xs text-luxury-gold uppercase tracking-widest mb-1">Payment</p>
                    <p className="font-semibold text-sm">{PAYMENT_OPTIONS.find(o => o.id === paymentMethod)?.label}</p>
                  </div>
                  <button onClick={() => setStep(1)} className="text-xs text-luxury-gold hover:underline">Edit</button>
                </div>
              </div>

              <div className="p-4 bg-white/[0.02] border border-luxury-gold/15 rounded-xl mb-5">
                <p className="text-xs text-luxury-gold uppercase tracking-widest mb-3">Items ({cartItems.length})</p>
                <div className="space-y-2">
                  {cartItems.map(item => (
                    <div key={`${item.product.id}-${item.size}`} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{item.product.emoji}</span>
                        <div>
                          <p className="font-medium text-xs">{item.product.name}</p>
                          <p className="text-[10px] text-luxury-light/40">Size: {item.size} × {item.quantity}</p>
                        </div>
                      </div>
                      <span className="text-luxury-gold font-semibold text-xs">₹{(item.product.price * item.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex items-center gap-1.5 px-4 py-2.5 border border-luxury-gold/20 text-luxury-light/60 rounded-xl text-sm hover:text-luxury-gold hover:border-luxury-gold/40 transition-colors">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <motion.button
                  onClick={placeOrderNow}
                  disabled={placing}
                  whileHover={{ scale: placing ? 1 : 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex-1 py-2.5 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {placing ? (
                    <><span className="w-4 h-4 border-2 border-luxury-black/40 border-t-luxury-black rounded-full animate-spin" /> Placing Order…</>
                  ) : (
                    <>Place Order · ₹{finalTotal.toLocaleString()}</>
                  )}
                </motion.button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 border border-luxury-gold/15 rounded-2xl p-5 bg-white/[0.02]">
            <h3 className="font-playfair font-bold text-luxury-gold mb-4">Order Summary</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto mb-4">
              {cartItems.map(item => (
                <div key={`${item.product.id}-${item.size}`} className="flex items-center gap-2 text-xs">
                  <span className="text-xl shrink-0">{item.product.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="truncate">{item.product.name}</p>
                    <p className="text-luxury-light/40">×{item.quantity}</p>
                  </div>
                  <span className="text-luxury-gold shrink-0">₹{(item.product.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-luxury-gold/10 pt-3 space-y-1.5 text-sm">
              <div className="flex justify-between text-luxury-light/60"><span>Subtotal</span><span>₹{cartTotal.toLocaleString()}</span></div>
              <div className="flex justify-between text-luxury-light/60"><span>Delivery</span><span>{deliveryFee === 0 ? <span className="text-green-400">FREE</span> : `₹${deliveryFee}`}</span></div>
            </div>
            <div className="flex justify-between font-bold mt-3 pt-3 border-t border-luxury-gold/15 text-luxury-gold font-playfair">
              <span>Total</span><span>₹{finalTotal.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
