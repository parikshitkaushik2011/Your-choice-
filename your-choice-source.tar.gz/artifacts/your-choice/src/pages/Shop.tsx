import { useState, useMemo } from 'react'
import { useSearch } from 'wouter'
import { motion } from 'framer-motion'
import { SlidersHorizontal, LayoutGrid, List, X, ChevronDown } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import { products } from '../data/products'

const CATEGORIES = ['all', 'men', 'women', 'kids', 'accessories'] as const
const SORT_OPTIONS = [
  { label: 'Newest', value: 'newest' },
  { label: 'Price: Low to High', value: 'price-asc' },
  { label: 'Price: High to Low', value: 'price-desc' },
  { label: 'Rating', value: 'rating' },
  { label: 'Discount', value: 'discount' },
]

export default function Shop() {
  const search = useSearch()
  const params = new URLSearchParams(search)
  const urlCategory = params.get('category') || 'all'
  const urlSearch = params.get('search') || ''

  const [category, setCategory] = useState(urlCategory)
  const [searchQ, setSearchQ] = useState(urlSearch)
  const [sort, setSort] = useState('newest')
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [priceMax, setPriceMax] = useState(25000)
  const [showFilters, setShowFilters] = useState(false)

  const filtered = useMemo(() => {
    let list = [...products]

    if (category !== 'all') {
      list = list.filter(p => p.category === category)
    }

    if (searchQ.trim()) {
      const q = searchQ.toLowerCase()
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.subcategory.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      )
    }

    list = list.filter(p => p.price <= priceMax)

    switch (sort) {
      case 'price-asc': list.sort((a, b) => a.price - b.price); break
      case 'price-desc': list.sort((a, b) => b.price - a.price); break
      case 'rating': list.sort((a, b) => b.rating - a.rating); break
      case 'discount': list.sort((a, b) => (b.originalPrice - b.price) / b.originalPrice - (a.originalPrice - a.price) / a.originalPrice); break
      default: list.sort((a, b) => (a.isNew === b.isNew ? 0 : a.isNew ? -1 : 1))
    }

    return list
  }, [category, searchQ, sort, priceMax])

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Page Header */}
      <div className="mb-8">
        <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">Our Collection</p>
        <h1 className="text-3xl font-playfair font-bold">
          {category === 'all' ? 'All Products' : category.charAt(0).toUpperCase() + category.slice(1) + ' Collection'}
        </h1>
        {searchQ && <p className="text-luxury-light/50 text-sm mt-1">Results for "{searchQ}"</p>}
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 flex-wrap mb-6">
        {CATEGORIES.map(c => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${category === c ? 'bg-luxury-gold text-luxury-black' : 'border border-luxury-gold/25 text-luxury-light/70 hover:border-luxury-gold/60 hover:text-luxury-gold'}`}
          >
            {c === 'all' ? 'All' : c.charAt(0).toUpperCase() + c.slice(1)}
          </button>
        ))}
      </div>

      <div className="flex gap-6">
        {/* Sidebar Filters */}
        <motion.aside
          animate={{ x: showFilters || window.innerWidth >= 1024 ? 0 : -300 }}
          className={`shrink-0 w-56 ${showFilters ? 'block' : 'hidden lg:block'}`}
        >
          <div className="sticky top-24 space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-luxury-gold mb-3 uppercase tracking-widest">Search</h3>
              <div className="relative">
                <input
                  value={searchQ}
                  onChange={e => setSearchQ(e.target.value)}
                  placeholder="Search products..."
                  className="w-full px-3 py-2 text-sm bg-white/5 border border-luxury-gold/20 rounded-lg text-white placeholder-luxury-light/30 focus:outline-none focus:border-luxury-gold transition-colors"
                />
                {searchQ && (
                  <button onClick={() => setSearchQ('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-luxury-light/40 hover:text-luxury-gold">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-luxury-gold mb-3 uppercase tracking-widest">Max Price</h3>
              <input
                type="range"
                min={500}
                max={25000}
                step={500}
                value={priceMax}
                onChange={e => setPriceMax(Number(e.target.value))}
                className="w-full accent-luxury-gold"
              />
              <div className="flex justify-between text-xs text-luxury-light/50 mt-1">
                <span>₹500</span>
                <span className="text-luxury-gold font-semibold">₹{priceMax.toLocaleString()}</span>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-luxury-gold mb-3 uppercase tracking-widest">Category</h3>
              <div className="space-y-1">
                {CATEGORIES.map(c => (
                  <button
                    key={c}
                    onClick={() => setCategory(c)}
                    className={`block w-full text-left px-3 py-1.5 text-sm rounded-lg transition-colors ${category === c ? 'text-luxury-gold bg-luxury-gold/10' : 'text-luxury-light/60 hover:text-luxury-gold hover:bg-luxury-gold/5'}`}
                  >
                    {c === 'all' ? 'All Categories' : c.charAt(0).toUpperCase() + c.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.aside>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Toolbar */}
          <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <button onClick={() => setShowFilters(v => !v)} className="lg:hidden flex items-center gap-1.5 px-3 py-1.5 border border-luxury-gold/25 rounded-lg text-sm text-luxury-light/70 hover:text-luxury-gold hover:border-luxury-gold/50 transition-colors">
                <SlidersHorizontal className="w-4 h-4" /> Filters
              </button>
              <span className="text-sm text-luxury-light/40">{filtered.length} products</span>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <select
                  value={sort}
                  onChange={e => setSort(e.target.value)}
                  className="appearance-none bg-white/5 border border-luxury-gold/20 rounded-lg px-3 py-1.5 pr-7 text-sm text-luxury-light/80 focus:outline-none focus:border-luxury-gold cursor-pointer"
                >
                  {SORT_OPTIONS.map(o => <option key={o.value} value={o.value} className="bg-luxury-black">{o.label}</option>)}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-luxury-gold/60 pointer-events-none" />
              </div>

              <div className="flex border border-luxury-gold/20 rounded-lg overflow-hidden">
                <button onClick={() => setView('grid')} className={`p-1.5 transition-colors ${view === 'grid' ? 'bg-luxury-gold text-luxury-black' : 'text-luxury-light/50 hover:text-luxury-gold'}`}>
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button onClick={() => setView('list')} className={`p-1.5 transition-colors ${view === 'list' ? 'bg-luxury-gold text-luxury-black' : 'text-luxury-light/50 hover:text-luxury-gold'}`}>
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Products */}
          {filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-6xl mb-4">🔍</p>
              <p className="text-luxury-light/50 text-lg">No products found</p>
              <button onClick={() => { setSearchQ(''); setCategory('all'); setPriceMax(25000) }} className="mt-4 px-5 py-2 border border-luxury-gold/30 text-luxury-gold rounded-lg hover:bg-luxury-gold/5 transition-colors text-sm">
                Clear Filters
              </button>
            </div>
          ) : view === 'grid' ? (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {filtered.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(p => <ProductCard key={p.id} product={p} view="list" />)}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
