import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { ShoppingBag, Package, Users, TrendingUp, BarChart2, Star } from 'lucide-react'
import { useApp } from '../store'
import { products, getFeaturedProducts } from '../data/products'

const TABS = ['Dashboard', 'Orders', 'Products']

export default function Admin() {
  const { user, orders } = useApp()
  const [, navigate] = useLocation()
  const [tab, setTab] = useState('Dashboard')

  if (!user || user.email !== 'admin@yourchoice.com') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <p className="text-6xl mb-4">🔒</p>
        <h2 className="text-2xl font-playfair font-bold mb-3">Admin Access Only</h2>
        <p className="text-luxury-light/50 text-sm mb-6">You need admin privileges to view this page.</p>
        <button onClick={() => navigate('/')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Go Home</button>
      </div>
    )
  }

  const totalRevenue = orders.reduce((s, o) => s + o.total, 0)
  const categoryCount = Object.fromEntries(['men', 'women', 'kids', 'accessories'].map(c => [c, products.filter(p => p.category === c).length]))

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-luxury-gold text-xs tracking-widest uppercase mb-1">Management</p>
          <h1 className="text-3xl font-playfair font-bold">Admin Panel</h1>
        </div>
        <span className="px-3 py-1 bg-luxury-gold/15 border border-luxury-gold/30 rounded-full text-luxury-gold text-xs font-bold">Admin</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border border-luxury-gold/20 rounded-xl p-1 w-fit mb-8">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2 text-sm font-semibold rounded-lg transition-all ${tab === t ? 'bg-luxury-gold text-luxury-black' : 'text-luxury-light/60 hover:text-luxury-gold'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Dashboard' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {/* Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { icon: ShoppingBag, label: 'Total Products', val: products.length, color: 'text-blue-400' },
              { icon: Package, label: 'Total Orders', val: orders.length, color: 'text-yellow-400' },
              { icon: TrendingUp, label: 'Revenue', val: `₹${totalRevenue.toLocaleString()}`, color: 'text-luxury-gold' },
              { icon: Star, label: 'Featured', val: getFeaturedProducts().length, color: 'text-purple-400' },
            ].map(({ icon: Icon, label, val, color }) => (
              <div key={label} className="p-5 border border-luxury-gold/15 rounded-2xl bg-white/[0.02] hover:border-luxury-gold/30 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs text-luxury-light/40 uppercase tracking-widest">{label}</p>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <p className={`text-2xl font-playfair font-bold ${color}`}>{val}</p>
              </div>
            ))}
          </div>

          {/* Category Breakdown */}
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="p-5 border border-luxury-gold/15 rounded-2xl bg-white/[0.02]">
              <div className="flex items-center gap-2 mb-4">
                <BarChart2 className="w-5 h-5 text-luxury-gold" />
                <h3 className="font-playfair font-bold">Products by Category</h3>
              </div>
              <div className="space-y-3">
                {Object.entries(categoryCount).map(([cat, count]) => (
                  <div key={cat}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="capitalize text-luxury-light/70">{cat}</span>
                      <span className="text-luxury-gold font-semibold">{count}</span>
                    </div>
                    <div className="h-1.5 bg-luxury-gold/10 rounded-full overflow-hidden">
                      <div className="h-full bg-luxury-gold rounded-full" style={{ width: `${(count / products.length) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 border border-luxury-gold/15 rounded-2xl bg-white/[0.02]">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-luxury-gold" />
                <h3 className="font-playfair font-bold">Recent Orders</h3>
              </div>
              {orders.length === 0 ? (
                <p className="text-luxury-light/40 text-sm text-center py-6">No orders yet</p>
              ) : (
                <div className="space-y-3">
                  {orders.slice(0, 5).map(o => (
                    <div key={o.id} className="flex items-center justify-between text-sm">
                      <div>
                        <p className="font-semibold text-luxury-gold text-xs">{o.id}</p>
                        <p className="text-luxury-light/40 text-[10px]">{o.address.fullName} · {o.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-xs">₹{o.total.toLocaleString()}</p>
                        <span className="text-[10px] px-2 py-0.5 bg-green-500/10 text-green-400 border border-green-500/20 rounded-full">{o.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}

      {tab === 'Orders' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {orders.length === 0 ? (
            <div className="text-center py-20">
              <Package className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
              <p className="text-luxury-light/50">No orders received yet</p>
            </div>
          ) : (
            <div className="border border-luxury-gold/15 rounded-2xl overflow-hidden">
              <div className="grid grid-cols-5 px-5 py-3 text-xs text-luxury-light/40 uppercase tracking-widest bg-luxury-gold/[0.03] border-b border-luxury-gold/10">
                <span>Order ID</span><span>Customer</span><span>Items</span><span>Total</span><span>Status</span>
              </div>
              <div className="divide-y divide-luxury-gold/5">
                {orders.map(o => (
                  <div key={o.id} className="grid grid-cols-5 items-center px-5 py-3.5 text-sm hover:bg-luxury-gold/[0.02] transition-colors">
                    <span className="text-luxury-gold font-bold text-xs">{o.id}</span>
                    <span className="text-luxury-light/70 truncate">{o.address.fullName}</span>
                    <span className="text-luxury-light/50">{o.items.length} item{o.items.length > 1 ? 's' : ''}</span>
                    <span className="font-semibold">₹{o.total.toLocaleString()}</span>
                    <span className="px-2 py-0.5 w-fit text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 rounded-full font-bold">{o.status}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}

      {tab === 'Products' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="border border-luxury-gold/15 rounded-2xl overflow-hidden">
            <div className="grid grid-cols-5 px-5 py-3 text-xs text-luxury-light/40 uppercase tracking-widest bg-luxury-gold/[0.03] border-b border-luxury-gold/10">
              <span className="col-span-2">Product</span><span>Price</span><span>Rating</span><span>Stock</span>
            </div>
            <div className="divide-y divide-luxury-gold/5 max-h-[600px] overflow-y-auto">
              {products.map(p => (
                <div key={p.id} className="grid grid-cols-5 items-center px-5 py-3 text-sm hover:bg-luxury-gold/[0.02] transition-colors cursor-pointer" onClick={() => navigate(`/product/${p.id}`)}>
                  <div className="col-span-2 flex items-center gap-2">
                    <span className="text-xl">{p.emoji}</span>
                    <div>
                      <p className="font-semibold text-xs truncate">{p.name}</p>
                      <p className="text-[10px] text-luxury-light/40 capitalize">{p.category}</p>
                    </div>
                  </div>
                  <span className="text-luxury-gold font-semibold">₹{p.price.toLocaleString()}</span>
                  <span className="text-luxury-gold">⭐ {p.rating}</span>
                  <span className={`w-fit px-2 py-0.5 text-[10px] rounded-full font-bold border ${p.inStock ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                    {p.inStock ? 'In Stock' : 'Out'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  )
}
