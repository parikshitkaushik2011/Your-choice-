import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { User, Phone, Mail, Save, Package, Heart, LogOut, Shield } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '../store'

export default function Profile() {
  const { user, logout, updateUser, orders, wishlistItems } = useApp()
  const [, navigate] = useLocation()
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '' })
  const [saving, setSaving] = useState(false)

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <User className="w-16 h-16 text-luxury-gold/20 mx-auto mb-4" />
        <h2 className="text-2xl font-playfair font-bold mb-3">Please sign in</h2>
        <button onClick={() => navigate('/login')} className="px-8 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl">Sign In</button>
      </div>
    )
  }

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 600))
    updateUser({ name: form.name.trim(), phone: form.phone.trim() })
    setSaving(false)
    setEditing(false)
    toast.success('Profile updated!', { icon: '✅' })
  }

  const handleLogout = () => {
    logout()
    toast('Logged out', { icon: '👋' })
    navigate('/')
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-playfair font-bold mb-8">My Account</h1>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        {[
          { icon: Package, label: 'Total Orders', val: orders.length, href: '/orders', color: 'text-blue-400' },
          { icon: Heart, label: 'Wishlist Items', val: wishlistItems.length, href: '/wishlist', color: 'text-red-400' },
          { icon: Shield, label: 'Member Since', val: '2026', href: null, color: 'text-luxury-gold' },
        ].map(({ icon: Icon, label, val, href, color }) => (
          <motion.div
            key={label}
            whileHover={href ? { y: -3 } : {}}
            onClick={() => href && navigate(href)}
            className={`p-5 border border-luxury-gold/15 rounded-2xl bg-white/[0.02] text-center ${href ? 'cursor-pointer hover:border-luxury-gold/40' : ''} transition-all`}
          >
            <Icon className={`w-7 h-7 mx-auto mb-2 ${color}`} />
            <p className="text-2xl font-playfair font-bold text-luxury-gold">{val}</p>
            <p className="text-xs text-luxury-light/50 mt-1">{label}</p>
          </motion.div>
        ))}
      </div>

      {/* Profile Info */}
      <div className="border border-luxury-gold/20 rounded-3xl p-6 bg-white/[0.02] mb-5">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-playfair font-bold text-xl text-luxury-gold">Personal Information</h2>
          {!editing ? (
            <button onClick={() => setEditing(true)} className="px-4 py-1.5 border border-luxury-gold/30 text-luxury-gold text-sm rounded-lg hover:bg-luxury-gold/5 transition-colors">
              Edit
            </button>
          ) : (
            <div className="flex gap-2">
              <button onClick={() => setEditing(false)} className="px-4 py-1.5 border border-luxury-gold/20 text-luxury-light/50 text-sm rounded-lg hover:text-luxury-gold transition-colors">
                Cancel
              </button>
              <motion.button
                onClick={handleSave}
                disabled={saving}
                whileHover={{ scale: 1.02 }}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-luxury-gold text-luxury-black text-sm font-bold rounded-lg disabled:opacity-70"
              >
                {saving ? <span className="w-3.5 h-3.5 border-2 border-luxury-black/40 border-t-luxury-black rounded-full animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                Save
              </motion.button>
            </div>
          )}
        </div>

        <div className="space-y-5">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-luxury-gold/10 border border-luxury-gold/20 flex items-center justify-center shrink-0 mt-0.5">
              <User className="w-5 h-5 text-luxury-gold" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-luxury-light/40 uppercase tracking-widest mb-1">Full Name</p>
              {editing ? (
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="w-full bg-white/5 border border-luxury-gold/20 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-luxury-gold transition-colors" />
              ) : (
                <p className="font-semibold">{user.name}</p>
              )}
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-luxury-gold/10 border border-luxury-gold/20 flex items-center justify-center shrink-0 mt-0.5">
              <Mail className="w-5 h-5 text-luxury-gold" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-luxury-light/40 uppercase tracking-widest mb-1">Email</p>
              <p className="font-semibold text-luxury-light/80">{user.email}</p>
              <p className="text-[10px] text-luxury-light/30 mt-0.5">Email cannot be changed</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-luxury-gold/10 border border-luxury-gold/20 flex items-center justify-center shrink-0 mt-0.5">
              <Phone className="w-5 h-5 text-luxury-gold" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-luxury-light/40 uppercase tracking-widest mb-1">Phone</p>
              {editing ? (
                <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} type="tel" className="w-full bg-white/5 border border-luxury-gold/20 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-luxury-gold transition-colors" />
              ) : (
                <p className="font-semibold">{user.phone || 'Not set'}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="flex items-center gap-2 px-5 py-2.5 border border-red-500/20 text-red-400 rounded-xl hover:bg-red-500/5 transition-colors text-sm"
      >
        <LogOut className="w-4 h-4" /> Sign Out
      </button>
    </div>
  )
}
