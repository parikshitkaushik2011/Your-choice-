import { useLocation } from 'wouter'
import { motion } from 'framer-motion'
import { ArrowLeft, Home } from 'lucide-react'

export default function NotFound() {
  const [, navigate] = useLocation()
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="text-8xl font-playfair font-bold text-luxury-gold mb-4">404</div>
        <h1 className="text-2xl font-playfair font-bold mb-3">Page Not Found</h1>
        <p className="text-luxury-light/50 text-sm mb-8 max-w-sm mx-auto">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => window.history.back()}
            className="flex items-center justify-center gap-2 px-6 py-3 border border-luxury-gold/30 text-luxury-gold rounded-xl hover:bg-luxury-gold/5 transition-colors font-semibold"
          >
            <ArrowLeft className="w-4 h-4" /> Go Back
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
          >
            <Home className="w-4 h-4" /> Go Home
          </button>
        </div>
      </motion.div>
    </div>
  )
}
