import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Plus, Minus, ShoppingBag, Trash2, ArrowRight } from 'lucide-react'
import { useApp } from '../store'

export default function CartDrawer() {
  const { isCartOpen, setCartOpen, cartItems, removeFromCart, updateQuantity, cartTotal } = useApp()
  const [, navigate] = useLocation()

  const handleCheckout = () => {
    setCartOpen(false)
    navigate('/checkout')
  }

  const handleViewCart = () => {
    setCartOpen(false)
    navigate('/cart')
  }

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
            onClick={() => setCartOpen(false)}
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-sm z-50 bg-luxury-black border-l border-luxury-gold/20 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-luxury-gold/15">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-luxury-gold" />
                <h2 className="font-playfair font-bold text-luxury-gold text-lg">Your Cart</h2>
                {cartItems.length > 0 && (
                  <span className="w-5 h-5 bg-luxury-gold text-luxury-black text-xs font-bold rounded-full flex items-center justify-center">
                    {cartItems.reduce((s, i) => s + i.quantity, 0)}
                  </span>
                )}
              </div>
              <button onClick={() => setCartOpen(false)} className="p-1.5 text-luxury-light/50 hover:text-luxury-gold transition-colors rounded-lg hover:bg-luxury-gold/5">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
              <AnimatePresence mode="popLayout">
                {cartItems.length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-64 text-center"
                  >
                    <ShoppingBag className="w-14 h-14 text-luxury-gold/20 mb-4" />
                    <p className="text-luxury-light/50 text-sm">Your cart is empty</p>
                    <button
                      onClick={() => { setCartOpen(false); navigate('/shop') }}
                      className="mt-4 px-5 py-2 bg-luxury-gold text-luxury-black text-sm font-bold rounded-lg"
                    >
                      Start Shopping
                    </button>
                  </motion.div>
                ) : (
                  cartItems.map(item => (
                    <motion.div
                      key={`${item.product.id}-${item.size}-${item.color}`}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="flex gap-3 p-3 bg-white/[0.03] border border-luxury-gold/10 rounded-xl"
                    >
                      <div className="w-16 h-16 bg-luxury-gold/5 rounded-lg flex items-center justify-center border border-luxury-gold/10 shrink-0">
                        <span className="text-3xl">{item.product.emoji}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between gap-1">
                          <h4 className="text-xs font-semibold font-playfair line-clamp-2 leading-tight">{item.product.name}</h4>
                          <button
                            onClick={() => removeFromCart(item.product.id, item.size, item.color)}
                            className="text-red-400/50 hover:text-red-400 transition-colors shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[10px] text-luxury-light/40 mt-0.5">Size: {item.size} · {item.color}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-luxury-gold font-bold text-sm">₹{(item.product.price * item.quantity).toLocaleString()}</span>
                          <div className="flex items-center gap-1.5 bg-luxury-black border border-luxury-gold/20 rounded-lg px-1.5 py-0.5">
                            <button onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity - 1)} className="text-luxury-light/60 hover:text-luxury-gold transition-colors">
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-semibold w-4 text-center">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.product.id, item.size, item.color, item.quantity + 1)} className="text-luxury-light/60 hover:text-luxury-gold transition-colors">
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>

            {/* Footer */}
            {cartItems.length > 0 && (
              <div className="px-5 py-4 border-t border-luxury-gold/15 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-luxury-light/60 text-sm">Subtotal</span>
                  <span className="font-playfair font-bold text-luxury-gold text-xl">₹{cartTotal.toLocaleString()}</span>
                </div>
                <p className="text-[10px] text-luxury-light/30 text-center">Shipping & taxes calculated at checkout</p>
                <button
                  onClick={handleCheckout}
                  className="w-full py-3 bg-luxury-gold text-luxury-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all flex items-center justify-center gap-2"
                >
                  Checkout <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={handleViewCart}
                  className="w-full py-2.5 border border-luxury-gold/30 text-luxury-gold text-sm font-semibold rounded-xl hover:bg-luxury-gold/5 transition-all"
                >
                  View Full Cart
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
