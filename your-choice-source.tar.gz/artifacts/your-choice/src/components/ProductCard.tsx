import { useState } from 'react'
import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react'
import { toast } from 'sonner'
import { Product } from '../data/products'
import { useApp } from '../store'

interface Props {
  product: Product
  view?: 'grid' | 'list'
}

export default function ProductCard({ product, view = 'grid' }: Props) {
  const { addToCart, toggleWishlist, isInWishlist, setCartOpen } = useApp()
  const [, navigate] = useLocation()
  const [showSizes, setShowSizes] = useState(false)
  const [selectedSize, setSelectedSize] = useState('')
  const inWishlist = isInWishlist(product.id)
  const discount = Math.round((1 - product.price / product.originalPrice) * 100)

  const handleAddToCart = () => {
    if (product.sizes.length > 1) {
      setShowSizes(v => !v)
    } else {
      addToCart(product, product.sizes[0], product.colors[0]?.name || 'Default')
      toast.success(`${product.name} added to cart!`, { icon: '🛒' })
      setCartOpen(true)
    }
  }

  const handleSizeSelect = (size: string) => {
    setSelectedSize(size)
    addToCart(product, size, product.colors[0]?.name || 'Default')
    toast.success(`${product.name} (${size}) added to cart!`, { icon: '🛒' })
    setShowSizes(false)
    setCartOpen(true)
  }

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation()
    toggleWishlist(product)
    toast(inWishlist ? 'Removed from wishlist' : 'Added to wishlist!', { icon: inWishlist ? '💔' : '❤️' })
  }

  if (view === 'list') {
    return (
      <motion.div
        layout
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex gap-4 p-4 border border-luxury-gold/15 rounded-xl bg-white/[0.02] hover:border-luxury-gold/40 transition-all duration-300"
      >
        <div
          className="w-28 h-28 sm:w-36 sm:h-36 bg-gradient-to-b from-luxury-gold/8 to-luxury-black rounded-lg flex items-center justify-center border border-luxury-gold/15 cursor-pointer shrink-0"
          onClick={() => navigate(`/product/${product.id}`)}
        >
          <span className="text-5xl">{product.emoji}</span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-[10px] text-luxury-gold uppercase tracking-widest">{product.category} · {product.subcategory}</span>
              <h3 className="font-playfair font-semibold text-base mt-0.5 cursor-pointer hover:text-luxury-gold transition-colors" onClick={() => navigate(`/product/${product.id}`)}>{product.name}</h3>
            </div>
            <button onClick={handleWishlist} className={`p-1.5 rounded-full transition-colors ${inWishlist ? 'text-red-400' : 'text-luxury-light/40 hover:text-red-400'}`}>
              <Heart className={`w-4 h-4 ${inWishlist ? 'fill-red-400' : ''}`} />
            </button>
          </div>
          <div className="flex items-center gap-1 mt-1">
            <Star className="w-3 h-3 text-luxury-gold fill-luxury-gold" />
            <span className="text-xs text-luxury-gold font-medium">{product.rating}</span>
            <span className="text-xs text-luxury-light/40">({product.reviewCount})</span>
          </div>
          <p className="text-xs text-luxury-light/50 mt-1 line-clamp-2 hidden sm:block">{product.description}</p>
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-luxury-gold font-bold text-lg">₹{product.price.toLocaleString()}</span>
              <span className="text-luxury-light/30 line-through text-sm">₹{product.originalPrice.toLocaleString()}</span>
              <span className="text-green-400 text-xs font-semibold">{discount}% off</span>
            </div>
            <button onClick={handleAddToCart} className="px-4 py-1.5 bg-luxury-gold/15 text-luxury-gold border border-luxury-gold/30 rounded-lg hover:bg-luxury-gold hover:text-luxury-black transition-all text-sm font-semibold">
              Add to Cart
            </button>
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative"
    >
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1">
        {product.isNew && <span className="px-2 py-0.5 bg-luxury-gold text-luxury-black text-[10px] font-bold rounded">NEW</span>}
        {discount >= 20 && <span className="px-2 py-0.5 bg-green-500 text-white text-[10px] font-bold rounded">{discount}% OFF</span>}
      </div>

      {/* Wishlist */}
      <button
        onClick={handleWishlist}
        className={`absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-luxury-black/70 backdrop-blur-sm border border-luxury-gold/20 flex items-center justify-center transition-all ${inWishlist ? 'text-red-400 border-red-400/30' : 'text-luxury-light/50 hover:text-red-400'}`}
      >
        <Heart className={`w-4 h-4 ${inWishlist ? 'fill-red-400' : ''}`} />
      </button>

      {/* Image */}
      <div
        className="relative h-60 bg-gradient-to-b from-luxury-gold/5 to-luxury-black rounded-2xl mb-3 flex items-center justify-center border border-luxury-gold/15 group-hover:border-luxury-gold/50 transition-all duration-300 overflow-hidden cursor-pointer"
        onClick={() => navigate(`/product/${product.id}`)}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-luxury-black/40 to-transparent pointer-events-none" />
        <motion.span className="text-7xl relative z-10" whileHover={{ scale: 1.15 }} transition={{ duration: 0.3 }}>
          {product.emoji}
        </motion.span>

        {/* Quick view overlay */}
        <div className="absolute inset-0 bg-luxury-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
          <span className="flex items-center gap-2 text-luxury-gold text-sm font-semibold">
            <Eye className="w-4 h-4" /> Quick View
          </span>
        </div>
      </div>

      {/* Info */}
      <div>
        <span className="text-[10px] text-luxury-gold/70 uppercase tracking-widest">{product.subcategory}</span>
        <h3
          className="font-playfair font-semibold text-sm mt-0.5 mb-1.5 cursor-pointer hover:text-luxury-gold transition-colors line-clamp-1"
          onClick={() => navigate(`/product/${product.id}`)}
        >
          {product.name}
        </h3>

        <div className="flex items-center gap-1 mb-2">
          <Star className="w-3 h-3 text-luxury-gold fill-luxury-gold" />
          <span className="text-xs text-luxury-gold font-medium">{product.rating}</span>
          <span className="text-xs text-luxury-light/40">({product.reviewCount})</span>
        </div>

        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-luxury-gold font-bold">₹{product.price.toLocaleString()}</span>
          <span className="text-luxury-light/30 line-through text-xs">₹{product.originalPrice.toLocaleString()}</span>
        </div>

        {/* Size selector popup */}
        <AnimatePresence>
          {showSizes && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="mb-2 flex flex-wrap gap-1"
            >
              {product.sizes.map(s => (
                <button
                  key={s}
                  onClick={() => handleSizeSelect(s)}
                  className="px-2 py-0.5 text-xs border border-luxury-gold/30 rounded text-luxury-gold hover:bg-luxury-gold hover:text-luxury-black transition-all"
                >
                  {s}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={handleAddToCart}
          className="w-full py-2 text-xs font-semibold bg-luxury-gold/10 text-luxury-gold border border-luxury-gold/25 rounded-lg hover:bg-luxury-gold hover:text-luxury-black transition-all duration-300 flex items-center justify-center gap-1.5"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          {showSizes ? 'Select Size' : 'Add to Cart'}
        </motion.button>
      </div>
    </motion.div>
  )
}
