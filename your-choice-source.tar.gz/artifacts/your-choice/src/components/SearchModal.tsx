import { useState, useEffect, useRef } from 'react'
import { useLocation } from 'wouter'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, X, TrendingUp, ArrowRight } from 'lucide-react'
import { products } from '../data/products'
import { useApp } from '../store'

const trending = ['Silk Saree', 'Sherwani', 'Anarkali', 'Lehenga', 'Kids Kurta']

export default function SearchModal() {
  const { isSearchOpen, setSearchOpen } = useApp()
  const [query, setQuery] = useState('')
  const [, navigate] = useLocation()
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (isSearchOpen) {
      setQuery('')
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [isSearchOpen])

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSearchOpen(false)
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [setSearchOpen])

  const results = query.length >= 2
    ? products.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.category.includes(query.toLowerCase()) ||
        p.tags.some(t => t.includes(query.toLowerCase()))
      ).slice(0, 6)
    : []

  const handleProductClick = (id: string) => {
    setSearchOpen(false)
    navigate(`/product/${id}`)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      setSearchOpen(false)
      navigate(`/shop?search=${encodeURIComponent(query.trim())}`)
    }
  }

  return (
    <AnimatePresence>
      {isSearchOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            onClick={() => setSearchOpen(false)}
          />

          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="fixed top-0 left-0 right-0 z-50 bg-luxury-black border-b border-luxury-gold/20 px-4 py-5 shadow-luxury-lg"
          >
            <div className="max-w-2xl mx-auto">
              <form onSubmit={handleSearch} className="flex items-center gap-3 mb-5">
                <Search className="w-5 h-5 text-luxury-gold shrink-0" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Search for sarees, kurtas, sherwanis…"
                  className="flex-1 bg-transparent text-white placeholder-luxury-light/30 outline-none text-lg"
                />
                {query && (
                  <button type="button" onClick={() => setQuery('')} className="text-luxury-light/40 hover:text-luxury-gold transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button type="button" onClick={() => setSearchOpen(false)} className="p-1.5 text-luxury-light/40 hover:text-luxury-gold transition-colors border border-luxury-gold/20 rounded-lg text-xs px-2">
                  Esc
                </button>
              </form>

              {/* Results */}
              <AnimatePresence mode="wait">
                {results.length > 0 ? (
                  <motion.div key="results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <p className="text-xs text-luxury-light/40 mb-3 uppercase tracking-widest">Results</p>
                    <div className="space-y-1">
                      {results.map(p => (
                        <motion.button
                          key={p.id}
                          onClick={() => handleProductClick(p.id)}
                          whileHover={{ x: 4 }}
                          className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-luxury-gold/5 transition-colors text-left group"
                        >
                          <span className="text-3xl w-10 h-10 flex items-center justify-center bg-luxury-gold/5 rounded-lg border border-luxury-gold/10">{p.emoji}</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate group-hover:text-luxury-gold transition-colors">{p.name}</p>
                            <p className="text-xs text-luxury-light/40">{p.category} · ₹{p.price.toLocaleString()}</p>
                          </div>
                          <ArrowRight className="w-4 h-4 text-luxury-gold/40 group-hover:text-luxury-gold transition-colors shrink-0" />
                        </motion.button>
                      ))}
                    </div>
                    <button
                      onClick={handleSearch}
                      className="mt-3 w-full py-2.5 border border-luxury-gold/20 text-luxury-gold text-sm rounded-xl hover:bg-luxury-gold/5 transition-colors"
                    >
                      See all results for "{query}"
                    </button>
                  </motion.div>
                ) : query.length >= 2 ? (
                  <motion.div key="no-results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-4">
                    <p className="text-luxury-light/50 text-sm">No results for "{query}"</p>
                  </motion.div>
                ) : (
                  <motion.div key="trending" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-4 h-4 text-luxury-gold" />
                      <p className="text-xs text-luxury-light/40 uppercase tracking-widest">Trending</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {trending.map(t => (
                        <button
                          key={t}
                          onClick={() => { setQuery(t); navigate(`/shop?search=${encodeURIComponent(t)}`); setSearchOpen(false) }}
                          className="px-3 py-1.5 border border-luxury-gold/20 rounded-full text-sm text-luxury-light/70 hover:text-luxury-gold hover:border-luxury-gold/40 transition-colors"
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
